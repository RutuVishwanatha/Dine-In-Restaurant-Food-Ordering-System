import { create } from 'zustand';
import { CartItem, TableSession } from '../types';

interface Store {
  tableSession: TableSession | null;
  setTableSession: (session: TableSession | null) => void;
  addToCart: (item: CartItem) => void;
  removeFromCart: (itemId: string) => void;
  updateQuantity: (itemId: string, quantity: number) => void;
  clearCart: () => void;
}

export const useStore = create<Store>((set) => ({
  tableSession: null,
  setTableSession: (session) => set({ tableSession: session }),
  addToCart: (item) =>
    set((state) => {
      if (!state.tableSession) return state;
      const existingItem = state.tableSession.cart.find((i) => i.id === item.id);
      const cart = existingItem
        ? state.tableSession.cart.map((i) =>
            i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
          )
        : [...state.tableSession.cart, { ...item, quantity: 1 }];
      return {
        tableSession: { ...state.tableSession, cart },
      };
    }),
  removeFromCart: (itemId) =>
    set((state) => {
      if (!state.tableSession) return state;
      return {
        tableSession: {
          ...state.tableSession,
          cart: state.tableSession.cart.filter((i) => i.id !== itemId),
        },
      };
    }),
  updateQuantity: (itemId, quantity) =>
    set((state) => {
      if (!state.tableSession) return state;
      return {
        tableSession: {
          ...state.tableSession,
          cart: state.tableSession.cart.map((i) =>
            i.id === itemId ? { ...i, quantity } : i
          ),
        },
      };
    }),
  clearCart: () =>
    set((state) => {
      if (!state.tableSession) return state;
      return {
        tableSession: { ...state.tableSession, cart: [] },
      };
    }),
}));