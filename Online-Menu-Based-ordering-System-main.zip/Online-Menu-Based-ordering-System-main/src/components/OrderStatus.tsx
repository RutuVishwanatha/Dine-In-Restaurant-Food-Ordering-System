import React, { useEffect, useState } from 'react';
import { useStore } from '../store/useStore';
import { Clock, CheckCircle2, ChefHat } from 'lucide-react';

const OrderStatus = () => {
  const { tableSession } = useStore();
  const [status, setStatus] = useState('preparing');

  useEffect(() => {
    // Simulate order status updates
    const timer = setTimeout(() => {
      setStatus('ready');
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="max-w-md mx-auto text-center">
      <h1 className="text-3xl font-bold mb-8">Order Status</h1>
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex justify-center mb-6">
          {status === 'preparing' ? (
            <ChefHat className="w-16 h-16 text-yellow-500 animate-bounce" />
          ) : (
            <CheckCircle2 className="w-16 h-16 text-green-500" />
          )}
        </div>
        <h2 className="text-2xl font-semibold mb-4">
          {status === 'preparing' ? 'Preparing Your Order' : 'Order Ready!'}
        </h2>
        <p className="text-gray-600 mb-6">
          {status === 'preparing'
            ? 'Our chefs are working on your delicious meal'
            : 'Your order is ready for pickup at the counter'}
        </p>
        {status === 'preparing' && (
          <div className="flex items-center justify-center gap-2 text-yellow-500">
            <Clock className="w-5 h-5" />
            <span>Estimated wait time: 10-15 minutes</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default OrderStatus;