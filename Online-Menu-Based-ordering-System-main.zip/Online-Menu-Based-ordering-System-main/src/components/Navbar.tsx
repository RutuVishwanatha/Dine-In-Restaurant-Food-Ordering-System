import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { ShoppingCart, UtensilsCrossed } from 'lucide-react';

const Navbar = () => {
  const location = useLocation();
  const { tableSession } = useStore();
  const cartItemCount = tableSession?.cart.reduce((sum, item) => sum + item.quantity, 0) ?? 0;

  if (location.pathname === '/') return null;

  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2">
            <UtensilsCrossed className="w-6 h-6 text-blue-600" />
            <span className="font-bold text-xl">RNSIT Restaurant</span>
          </Link>
          {tableSession && (
            <Link
              to="/cart"
              className="flex items-center gap-2 text-gray-600 hover:text-blue-600"
            >
              <div className="relative">
                <ShoppingCart className="w-6 h-6" />
                {cartItemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-blue-600 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                    {cartItemCount}
                  </span>
                )}
              </div>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;