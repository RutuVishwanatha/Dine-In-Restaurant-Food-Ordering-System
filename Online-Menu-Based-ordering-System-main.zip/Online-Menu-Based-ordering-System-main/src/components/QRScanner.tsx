import React, { useEffect, useState } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { useNavigate } from 'react-router-dom';
import { UtensilsCrossed } from 'lucide-react';

const QRScanner = () => {
  const navigate = useNavigate();
  const [scanning, setScanning] = useState(false);

  useEffect(() => {
    if (!scanning) {
      const scanner = new Html5QrcodeScanner('reader', {
        qrbox: {
          width: 250,
          height: 250,
        },
        fps: 5,
      });

      scanner.render(success, error);

      function success(result: string) {
        scanner.clear();
        const tableId = result.split('/').pop();
        navigate(`/menu/${tableId}`);
      }

      function error(err: any) {
        console.warn(err);
      }

      setScanning(true);
    }
  }, [scanning, navigate]);

  return (
    <div className="max-w-md mx-auto text-center">
      <div className="mb-8">
        <UtensilsCrossed className="w-16 h-16 mx-auto mb-4 text-blue-600" />
        <h1 className="text-3xl font-bold mb-2">RNSIT Restaurant</h1>
        <p className="text-gray-600">Scan the QR code at your table to begin ordering</p>
      </div>
      <div id="reader" className="border rounded-lg overflow-hidden"></div>
    </div>
  );
};

export default QRScanner;