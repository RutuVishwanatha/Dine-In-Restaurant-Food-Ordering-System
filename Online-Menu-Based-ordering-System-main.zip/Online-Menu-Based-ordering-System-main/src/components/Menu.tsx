import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { menuItems } from '../data/menuItems';
import { Plus } from 'lucide-react';
import toast from 'react-hot-toast';

const Menu = () => {
  const { tableId } = useParams();
  const { tableSession, setTableSession, addToCart } = useStore();

  useEffect(() => {
    if (!tableSession && tableId) {
      setTableSession({
        id: tableId,
        hostId: crypto.randomUUID(),
        members: [],
        cart: [],
        status: 'active'
      });
    }
  }, [tableId, tableSession, setTableSession]);

  const handleAddToCart = (item: any) => {
    addToCart(item);
    toast.success(`Added ${item.name} to cart`);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Our Menu</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {menuItems.map((item) => (
          <div key={item.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img src={item.image} alt={item.name} className="w-full h-48 object-cover" />
            <div className="p-4">
              <h3 className="text-xl font-semibold mb-2">{item.name}</h3>
              <p className="text-gray-600 mb-4">{item.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold">₹{item.price}</span>
                <button
                  onClick={() => handleAddToCart(item)}
                  className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4" />
                  Add to Cart
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Menu;