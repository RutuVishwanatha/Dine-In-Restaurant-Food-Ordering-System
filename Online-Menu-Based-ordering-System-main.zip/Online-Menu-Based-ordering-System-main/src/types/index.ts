export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
}

export interface CartItem extends MenuItem {
  quantity: number;
}

export interface TableSession {
  id: string;
  hostId: string;
  members: string[];
  cart: CartItem[];
  status: 'active' | 'completed';
  orderStatus?: 'preparing' | 'ready' | 'delivered';
}