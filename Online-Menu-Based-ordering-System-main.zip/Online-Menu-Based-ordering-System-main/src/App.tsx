import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import QRScanner from './components/QRScanner';
import Menu from './components/Menu';
import Cart from './components/Cart';
import OrderStatus from './components/OrderStatus';
import Navbar from './components/Navbar';

function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<QRScanner />} />
            <Route path="/menu/:tableId" element={<Menu />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/status" element={<OrderStatus />} />
          </Routes>
        </div>
        <Toaster position="bottom-center" />
      </div>
    </BrowserRouter>
  );
}

export default App;